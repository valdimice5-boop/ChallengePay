
CHALLENGEPAY - Ready-to-deploy bundle
=====================================

Përmban:
- frontend/  : statik single-page app (index.html) me PayPal sandbox demo + ad placeholder
- backend/   : Express server me endpoint /api/get-pack dhe /api/bank-transfer
- README_DEPLOY_CHALLENGEPAY.md : instruksione deploy të detajuara
- LICENSE, .gitignore

1) Si ta provosh lokal:
 - Unzip paketën
 - Në folderin backend:
    npm install
    node server.js
 - Hape në shfletues: http://localhost:5000

2) Deploy në Render (hap pas hapi)
 - Krijo një repo në GitHub dhe shtoje gjithë përmbajtjen e këtij paketimi.
 - Kalo te render.com dhe krijo një "Web Service"
   - Lidh me GitHub repo-n tënd
   - Start command: `npm install && npm start`
   - Root directory: `/backend`
 - Shto këto Environment Variables në Render:
   - PAYPAL_CLIENT_ID = (p.sh. sandbox id ose të lë bosh për demo)
   - BANK_ACCOUNT_NAME = "Valdi Mice"
   - BANK_IBAN = "AL00 0000 0000 0000 0000 0000 00"
   - ADMIN_EMAIL = "support@challengepay.example"
 - Pas deploy, hap URL-n që Render jep (p.sh. https://challengepay.onrender.com)

3) PayPal (Sandbox -> Live)
 - Për test përdor client-id sandbox: `sb` është i instaluar në demo (script src).
 - Për prod, krijo PayPal Business account dhe kthe client-id live në script:
   https://www.paypal.com/sdk/js?client-id=TU_CLIENT_ID&currency=EUR
 - Implemento webhooks PayPal për të verifikuar pagesat server-side dhe për të dhënë paketën vetëm pasi të jetë verifikuar.

4) Bank transfer
 - Zëvendëso BANK_IBAN me IBAN-in tënd real në Render env vars.
 - Për transferet, përdor endpoint /api/bank-transfer për verifikim (për prod, kërko fatura/screenshot dhe verifikim manual).

5) PWA (opsional)
 - Për ta bërë PWA, shto manifest.json dhe service worker; unë mund të ta bëj këtë si hap pas deploy.

6) Siguria
 - Në prod, zëvendëso in-memory store me DB (MongoDB) dhe shto rate-limiting, captcha, moderation.

7) Ndihmë
 - Nëse dëshiron, unë mund të lidh repo-n me Render për ty (nevojitet access GitHub invite)
 - Më thuaj dhe unë të udhëzoj hap pas hapi për vendosjen e PayPal live keys dhe për listën e detyrave admin.

Enjoy!
