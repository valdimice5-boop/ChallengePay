
const express = require('express');
const app = express();
const cors = require('cors');
const fs = require('fs');
const path = require('path');
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../frontend')));

// load questions
let QUESTIONS = [];
try {
  const csv = fs.readFileSync(path.join(__dirname, 'questions.csv'), 'utf8');
  QUESTIONS = csv.split(/\r?\n/).filter(Boolean).map(l=>({text:l}));
} catch(e){
  QUESTIONS = [{text:'Trego një histori kur ishe totalisht i turpshëm.'}];
}

const freeGrantTimestamps = {}; // ip -> timestamp

function randQuestions(n){
  const out=[]; const used=new Set();
  while(out.length < n && out.length < QUESTIONS.length){
    const i = Math.floor(Math.random()*QUESTIONS.length);
    if(!used.has(i)){ used.add(i); out.push(QUESTIONS[i]); }
  }
  return out;
}

app.get('/api/get-pack', (req,res)=>{
  const size = parseInt(req.query.size) || 3;
  const ip = req.headers['x-forwarded-for'] || req.connection.remoteAddress || 'unknown';
  if(size === 1){
    const last = freeGrantTimestamps[ip] || 0;
    const now = Date.now();
    if(now - last < 30*60*1000){
      return res.status(429).json({error:'Mund të marrësh pyetje falas çdo 30 minuta. Provoni më vonë.'});
    }
    freeGrantTimestamps[ip] = now;
    return res.json({questions: randQuestions(1), source:'ad'});
  }
  if(size === 3 || size === 10){
    return res.json({questions: randQuestions(size), source:'purchase'});
  }
  return res.json({questions: randQuestions(size)});
});

app.post('/api/bank-transfer', (req,res)=>{
  const {email, amount} = req.body || {};
  const size = amount >= 2 ? 10 : 3;
  return res.json({questions: randQuestions(size), note:'Demo: verifikim transferi manual.'});
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, ()=>console.log('Server running on port', PORT));
